fetch('/api/system/info').then(r=>r.json()).then(d=>{
  document.getElementById('hdr').textContent='Running as DHIS2 on DER '+d.version;
});
